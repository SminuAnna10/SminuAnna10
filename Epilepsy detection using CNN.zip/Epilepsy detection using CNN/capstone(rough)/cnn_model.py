import os

import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import (accuracy_score, f1_score, precision_score,
                             recall_score)
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

# Hyperparameters
batch_size = 32
img_size = 150
epochs = 20
learning_rate = 0.001

# Path to your training dataset
data_dir = r"C:\Users\tagore\Desktop\capstone(rough)\training"

# Data transformations (resizing and normalization)
data_transforms = transforms.Compose([
    transforms.Resize((img_size, img_size)),
    transforms.ToTensor(),
    transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])  # Normalization
])

# Loading datasets
train_data = datasets.ImageFolder(data_dir, transform=data_transforms)
train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True)

# Check class names and indices
print(train_data.class_to_idx)

# CNN Model Definition
class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()
        self.conv1 = nn.Conv2d(3, 32, 3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, 3, padding=1)
        self.conv3 = nn.Conv2d(64, 128, 3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(128 * 18 * 18, 512)
        self.fc2 = nn.Linear(512, 1)
        self.dropout = nn.Dropout(0.5)
        
    def forward(self, x):
        x = self.pool(torch.relu(self.conv1(x)))
        x = self.pool(torch.relu(self.conv2(x)))
        x = self.pool(torch.relu(self.conv3(x)))
        x = x.view(-1, 128 * 18 * 18)
        x = torch.relu(self.fc1(x))
        x = self.dropout(x)
        x = torch.sigmoid(self.fc2(x))
        return x

# Initialize model, loss function, and optimizer
model = CNN()
criterion = nn.BCELoss()  # Binary Cross Entropy Loss for binary classification
optimizer = optim.Adam(model.parameters(), lr=learning_rate)

# Function to calculate metrics
def calculate_metrics(true_labels, predictions):
    acc = accuracy_score(true_labels, predictions)
    precision = precision_score(true_labels, predictions)
    recall = recall_score(true_labels, predictions)
    f1 = f1_score(true_labels, predictions)
    return acc, precision, recall, f1

# Function to train the model and collect final metrics
def train_model(model, criterion, optimizer, train_loader, epochs=20):
    train_loss = []
    all_true_labels = []
    all_predictions = []
    
    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        epoch_true_labels = []
        epoch_predictions = []
        
        for inputs, labels in train_loader:
            labels = labels.float().unsqueeze(1)  # Reshape labels for BCELoss
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item() * inputs.size(0)
            
            # Collect predictions for metrics
            preds = (outputs > 0.5).squeeze().detach().cpu().numpy()
            epoch_predictions.extend(preds)
            epoch_true_labels.extend(labels.cpu().numpy())

        all_true_labels.extend(epoch_true_labels)
        all_predictions.extend(epoch_predictions)

        epoch_loss = running_loss / len(train_loader.dataset)
        train_loss.append(epoch_loss)
        
        # Calculate metrics for this epoch
        acc, precision, recall, f1 = calculate_metrics(epoch_true_labels, epoch_predictions)
        
        print(f"Epoch {epoch+1}/{epochs}")
        print(f"Loss: {epoch_loss:.4f}")
        print(f"Accuracy: {acc * 100:.2f}%")
        print(f"Precision: {precision:.2f}")
        print(f"Recall: {recall:.2f}")
        print(f"F1 Score: {f1:.2f}")
        print("-" * 30)
    
    # Calculate overall metrics after all epochs
    final_acc, final_precision, final_recall, final_f1 = calculate_metrics(all_true_labels, all_predictions)
    print("\nFinal Metrics After Training:")
    print(f"Final Accuracy: {final_acc * 100:.2f}%")
    print(f"Final Precision: {final_precision:.2f}")
    print(f"Final Recall: {final_recall:.2f}")
    print(f"Final F1 Score: {final_f1:.2f}")
    
    return train_loss

# Train the model and collect metrics
train_loss = train_model(model, criterion, optimizer, train_loader, epochs)

# Plot training loss
plt.plot(train_loss, label='Training Loss')
plt.legend()
plt.show()

# Save the model
torch.save(model.state_dict(), 'cnn_model.pth')




# import os

# import matplotlib.pyplot as plt
# import torch
# import torch.nn as nn
# import torch.optim as optim
# from torch.utils.data import DataLoader
# from torchvision import datasets, transforms

# # Hyperparameters
# batch_size = 32
# img_size = 150
# epochs = 10
# learning_rate = 0.001

# # Path to your training dataset
# data_dir = r"C:\Users\tagore\Desktop\capstone(rough)\training"

# # Data transformations (resizing and normalization + Data Augmentation)
# data_transforms = transforms.Compose([
#     transforms.Resize((img_size, img_size)),
#     transforms.RandomHorizontalFlip(),  # Data Augmentation
#     transforms.RandomRotation(10),
#     transforms.ToTensor(),
#     transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])  # Normalization
# ])

# # Loading datasets
# train_data = datasets.ImageFolder(data_dir, transform=data_transforms)

# # Create DataLoader
# train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True)

# # Check class names and indices
# print(train_data.class_to_idx)

# # CNN Model Definition
# class CNN(nn.Module):
#     def __init__(self):
#         super(CNN, self).__init__()
#         self.conv1 = nn.Conv2d(3, 32, 3, padding=1)
#         self.conv2 = nn.Conv2d(32, 64, 3, padding=1)
#         self.conv3 = nn.Conv2d(64, 128, 3, padding=1)
#         self.pool = nn.MaxPool2d(2, 2)
#         self.fc1 = nn.Linear(128 * 18 * 18, 512)
#         self.fc2 = nn.Linear(512, 1)
#         self.dropout = nn.Dropout(0.5)
        
#     def forward(self, x):
#         x = self.pool(torch.relu(self.conv1(x)))
#         x = self.pool(torch.relu(self.conv2(x)))
#         x = self.pool(torch.relu(self.conv3(x)))
#         x = x.view(-1, 128 * 18 * 18)
#         x = torch.relu(self.fc1(x))
#         x = self.dropout(x)
#         x = torch.sigmoid(self.fc2(x))
#         return x

# # Initialize model, loss function, and optimizer
# model = CNN()
# criterion = nn.BCELoss()  # Binary Cross Entropy Loss for binary classification
# optimizer = optim.Adam(model.parameters(), lr=learning_rate)

# # Function to train the model
# def train_model(model, criterion, optimizer, train_loader, epochs=10):
#     train_loss = []
#     for epoch in range(epochs):
#         model.train()
#         running_loss = 0.0
#         for inputs, labels in train_loader:
#             labels = labels.float().unsqueeze(1)  # Reshape labels for BCELoss
#             optimizer.zero_grad()
#             outputs = model(inputs)
#             loss = criterion(outputs, labels)
#             loss.backward()
#             optimizer.step()
#             running_loss += loss.item() * inputs.size(0)

#         train_loss.append(running_loss / len(train_loader.dataset))
        
#         print(f"Epoch {epoch+1}/{epochs}, Training Loss: {train_loss[-1]:.4f}")
    
#     return train_loss

# # Train the model
# train_loss = train_model(model, criterion, optimizer, train_loader, epochs)

# # Plot training loss
# plt.plot(train_loss, label='Training Loss')
# plt.legend()
# plt.show()

# # Save the model
# torch.save(model.state_dict(), 'cnn_model.pth') 








# import os

# import matplotlib.pyplot as plt
# import torch
# import torch.nn as nn
# import torch.optim as optim
# from torch.utils.data import DataLoader
# from torchvision import datasets, transforms

# # Hyperparameters
# batch_size = 32
# img_size = 150
# epochs = 10
# learning_rate = 0.001

# # Path to your training dataset
# data_dir = r"C:\Users\tagore\Desktop\capstone(rough)\training"

# # Data transformations (resizing and normalization)
# data_transforms = transforms.Compose([
#     transforms.Resize((img_size, img_size)),
#     transforms.ToTensor(),
#     transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])  # Normalization
# ])

# # Loading datasets
# train_data = datasets.ImageFolder(data_dir, transform=data_transforms)

# # Create DataLoader
# train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True)

# # Check class names and indices
# print(train_data.class_to_idx)

# # CNN Model Definition
# class CNN(nn.Module):
#     def __init__(self):
#         super(CNN, self).__init__()
#         self.conv1 = nn.Conv2d(3, 32, 3, padding=1)
#         self.conv2 = nn.Conv2d(32, 64, 3, padding=1)
#         self.conv3 = nn.Conv2d(64, 128, 3, padding=1)
#         self.pool = nn.MaxPool2d(2, 2)
#         self.fc1 = nn.Linear(128 * 18 * 18, 512)
#         self.fc2 = nn.Linear(512, 1)
#         self.dropout = nn.Dropout(0.5)
        
#     def forward(self, x):
#         x = self.pool(torch.relu(self.conv1(x)))
#         x = self.pool(torch.relu(self.conv2(x)))
#         x = self.pool(torch.relu(self.conv3(x)))
#         x = x.view(-1, 128 * 18 * 18)
#         x = torch.relu(self.fc1(x))
#         x = self.dropout(x)
#         x = torch.sigmoid(self.fc2(x))
#         return x

# # Initialize model, loss function, and optimizer
# model = CNN()
# criterion = nn.BCELoss()  # Binary Cross Entropy Loss for binary classification
# optimizer = optim.Adam(model.parameters(), lr=learning_rate)

# # Function to train the model
# def train_model(model, criterion, optimizer, train_loader, epochs=10):
#     train_loss = []
#     for epoch in range(epochs):
#         model.train()
#         running_loss = 0.0
#         for inputs, labels in train_loader:
#             labels = labels.float().unsqueeze(1)  # Reshape labels for BCELoss
#             optimizer.zero_grad()
#             outputs = model(inputs)
#             loss = criterion(outputs, labels)
#             loss.backward()
#             optimizer.step()
#             running_loss += loss.item() * inputs.size(0)

#         train_loss.append(running_loss / len(train_loader.dataset))
        
#         print(f"Epoch {epoch+1}/{epochs}, Training Loss: {train_loss[-1]:.4f}")
    
#     return train_loss

# # Train the model
# train_loss = train_model(model, criterion, optimizer, train_loader, epochs)

# # Plot training loss
# plt.plot(train_loss, label='Training Loss')
# plt.legend()
# plt.show()

# # Save the model
# torch.save(model.state_dict(), 'cnn_model.pth')
