import os

import torch
from flask import Flask, redirect, render_template, request, url_for
from PIL import Image
from torchvision import transforms
from werkzeug.utils import secure_filename

from cnn_model import CNN  # Your CNN model

# Flask setup
app = Flask(__name__)

# Dynamically set the upload folder
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the upload folder exists
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

# Allowed file extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

# Function to check if the uploaded file is valid
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Load the trained CNN model
model = CNN()
model.load_state_dict(torch.load('cnn_model.pth', map_location=torch.device('cpu')))
model.eval()

# Define the transformation for input images
transform = transforms.Compose([
    transforms.Resize((150, 150)),
    transforms.ToTensor(),
    transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
])

# Route for homepage
@app.route('/')
def index():
    return render_template('index.html')

# Route for handling file upload and prediction
@app.route('/upload', methods=['POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            
            # Debugging: Print the file path to check where the image is being saved
            print(f"File saved at: {file_path}")

            # Save the file
            file.save(file_path)

            # Prepare the image for the model
            image = Image.open(file_path)
            image = transform(image).unsqueeze(0)

            # Make prediction using the CNN model
            output = model(image)
            prediction = 'Yes' if output > 0.5 else 'No'

            # Render the result page with the prediction and uploaded image
            return render_template('index.html', prediction=prediction, filename=filename)

# Route to serve uploaded files (display images)
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return redirect(url_for('static', filename='uploads/' + filename))

if __name__ == '__main__':
    app.run(debug=True)
