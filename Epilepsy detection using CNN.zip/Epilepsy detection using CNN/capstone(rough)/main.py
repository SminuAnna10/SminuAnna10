import torch
import torch.nn as nn
import torchvision.transforms as transforms
from sklearn.metrics import (accuracy_score, f1_score, precision_score,
                             recall_score)
from torch.utils.data import DataLoader
from torchvision.datasets import ImageFolder

from cnn_model import CNN

# Paths
TEST_DATA_PATH = r"C:\Users\tagore\Desktop\capstone(rough)\testing"

# Load the model
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = CNN()
model.load_state_dict(torch.load('cnn_model.pth', map_location=device))
model.to(device)
model.eval()

# Data Preprocessing and Loading
transform = transforms.Compose([
    transforms.Resize((150, 150)),
    transforms.ToTensor(),
    transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
])

test_data = ImageFolder(root=TEST_DATA_PATH, transform=transform)
test_loader = DataLoader(test_data, batch_size=32, shuffle=False)

# Lists for storing true labels and predictions
true_labels = []
predictions = []

# Inference
with torch.no_grad():
    for inputs, labels in test_loader:
        inputs, labels = inputs.to(device), labels.to(device)
        outputs = model(inputs)
        preds = (outputs > 0.5).squeeze().cpu().numpy()
        predictions.extend(preds)
        true_labels.extend(labels.cpu().numpy())

# Calculate Metrics
accuracy = accuracy_score(true_labels, predictions)
precision = precision_score(true_labels, predictions)
recall = recall_score(true_labels, predictions)
f1 = f1_score(true_labels, predictions)

# Display Metrics
print(f"Accuracy: {accuracy * 100:.2f}%")
print(f"Precision: {precision:.2f}")
print(f"Recall: {recall:.2f}")
print(f"F1 Score: {f1:.2f}")






# import os

# import numpy as np
# import torch
# import torch.nn as nn
# import torchvision.transforms as transforms
# from sklearn.metrics import (accuracy_score, f1_score, precision_score,
#                              recall_score)
# from torch.utils.data import DataLoader
# from torchvision.datasets import ImageFolder

# from cnn_model import CNN

# # Paths
# TEST_DATA_PATH = r"C:\Users\tagore\Desktop\capstone(rough)\testing"

# # Load the model
# device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# model = CNN()
# model.load_state_dict(torch.load('cnn_model.pth', map_location=device))
# model.to(device)
# model.eval()

# # Data Preprocessing and Loading
# transform = transforms.Compose([
#     transforms.Resize((150, 150)),  # Match input size during training
#     transforms.ToTensor(),
#     transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
# ])

# test_data = ImageFolder(root=TEST_DATA_PATH, transform=transform)
# test_loader = DataLoader(test_data, batch_size=32, shuffle=False)

# # Lists for storing true labels and predictions
# true_labels = []
# predictions = []

# # Inference
# with torch.no_grad():
#     for inputs, labels in test_loader:
#         inputs, labels = inputs.to(device), labels.to(device)
#         outputs = model(inputs)
#         preds = (outputs > 0.5).squeeze().cpu().numpy()
#         predictions.extend(preds)
#         true_labels.extend(labels.cpu().numpy())

# # Calculate Metrics
# accuracy = accuracy_score(true_labels, predictions)
# precision = precision_score(true_labels, predictions)
# recall = recall_score(true_labels, predictions)
# f1 = f1_score(true_labels, predictions)

# # Display Metrics
# print(f"Accuracy: {accuracy * 100:.2f}%")
# print(f"Precision: {precision:.2f}")
# print(f"Recall: {recall:.2f}")
# print(f"F1 Score: {f1:.2f}")
